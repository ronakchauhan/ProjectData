<?php
/**
 * Copyright © 2016 Czone Technologies. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'CzoneTech_Slider',
    __DIR__
);
