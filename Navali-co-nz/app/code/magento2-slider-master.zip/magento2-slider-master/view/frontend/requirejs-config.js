var config = {
    map: {
        '*' : {
            'owlcarousel' : 'CzoneTech_Slider/js/owl.carousel'
        }
    }
};
